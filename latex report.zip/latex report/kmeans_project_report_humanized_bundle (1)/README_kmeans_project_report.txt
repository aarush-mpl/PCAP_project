Scalable Parallel K-Means Clustering Using MPI and CUDA

Files
- kmeans_project_report_humanized.tex: editable LaTeX source
- kmeans_project_report_humanized.pdf: compiled nine-page report preview
- kmeans_performance.png: runtime and speedup graph referenced by the TeX source

Compile
Place these files in the same directory, then run:
  latexmk -pdf kmeans_project_report_humanized.tex

Execution screenshots
The materials provided for this revision did not include terminal screenshots from the serial, MPI, and CUDA runs. The report therefore contains clearly marked placeholders. To replace them, save genuine screenshots beside the TeX file as:
  serial_execution.png
  mpi_execution.png
  cuda_execution.png
Then compile the source again.

The report presents the measured runtime values from the supplied graph and does not infer unprovided hardware details or raw per-run statistics.
